== NOTES:

It can only have one Page not found by site, otherwise, we can say which one
will be choosed.

The Page HAVE TO be et has hidden to be hidden from children list.


== LICENSE:

 Frog CMS - Content Management Simplified. <http://www.madebyfrog.com>
 Copyright (C) 2008 Philippe Archambault <philippe.archambault@gmail.com>

 This file is part of Frog CMS.

 Frog CMS is free software: you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation, either version 3 of the License, or
 (at your option) any later version.

 Frog CMS is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with Frog CMS.  If not, see <http://www.gnu.org/licenses/>.

 Frog CMS has made an exception to the GNU General Public License for plugins.
 See exception.txt for details and the full text.