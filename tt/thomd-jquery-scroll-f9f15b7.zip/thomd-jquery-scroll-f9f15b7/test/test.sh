#!/bin/sh

java -jar test/lib/JsTestDriver-1.2.2.jar --config test/scroll.conf --tests all
