if (!jstestdriver) {
  jstestdriver = {};
}

jstestdriver.fixtures = function(){

  /*:DOC +=
  <div id="fixture_1" style="height:100px;">
    <div>1</div>
    <div>2</div>
    <div>3</div>
    <div>4</div>
    <div>5</div>
    <div>6</div>
    <div>7</div>
    <div>8</div>
    <div>9</div>
    <div>10</div>
    <div>11</div>
    <div>12</div>
    <div>13</div>
    <div>14</div>
    <div>15</div>
    <div>16</div>
    <div>17</div>
    <div>18</div>
    <div>19</div>
    <div>20</div>
  </div>
  */

  /*:DOC +=
  <div id="fixture_2">
    <div>1</div>
    <div>2</div>
    <div>3</div>
    <div>4</div>
    <div>5</div>
    <div>6</div>
    <div>7</div>
    <div>8</div>
    <div>9</div>
    <div>10</div>
    <div>11</div>
    <div>12</div>
    <div>13</div>
    <div>14</div>
    <div>15</div>
    <div>16</div>
    <div>17</div>
    <div>18</div>
    <div>19</div>
    <div>20</div>
  </div>
  */

  return {

    // an block element with block elements inside and a fixed height of 100px
    fixture_1: $('#fixture_1'),

    // an block element with block elements inside and a natural flowed height
    fixture_2: $('#fixture_2')
  };
};

