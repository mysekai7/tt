open -W -a Google\ Chrome $1
