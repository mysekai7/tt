open -W -a Firefox $1
