open -W -a Safari $1
