== WHAT IT IS ==

The multi lang plugin allows you to add translations of your pages.

== HOW TO USE IT ==

* Enable the plugin
* Access the settings page for the plugin and make your choices.

== NOTES ==

* The plugin only excepts ISO 639-1 language codes, just as the Wolf CMS core does.

* Currently, the plugin allows you to choose one and only one source for
  determining which language a user prefers.

== LICENSE ==

Copyright 2010, Martijn van der Kleijn. <martijn.niji@gmail.com>
This demo plugin is licensed under the GPLv3 License.
<http://www.gnu.org/licenses/gpl.html>