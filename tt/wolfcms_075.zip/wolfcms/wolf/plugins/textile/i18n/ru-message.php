<?php

   /**
     * Russian language file
     *
     * @package Plugins
     * @subpackage textile
     *
     * @author Dmitry Kostromin <kostromind@gmail.com>
     * @version Wolf 0.6.0
     * @last modifed from 07 February 2010
     */
	 
	 
	 
    return array(
    'Allows you to compose page parts or snippets using the Textile text filter.' => 'Позволяет создавать страницы или фрагменты с использованием текстового фильтра Textile',
	'Textile filter' => 'Фильтр Textile',
    );