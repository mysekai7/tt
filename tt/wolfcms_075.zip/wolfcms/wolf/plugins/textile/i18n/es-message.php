<?php

    /**
     * Spanish file for plugin textile
     *
     * @package Plugins
     * @subpackage textile
     *
     * @author andrewmman
     * @version Wolf 0.6.0
     */

    return array(
    	'Allows you to compose page parts or snippets using the Textile text filter.' => 'Permite componer piezas de una página o fragmentos usando el filtro de texto Textile.',
	'Textile filter' => 'Filtro Textile',
    );