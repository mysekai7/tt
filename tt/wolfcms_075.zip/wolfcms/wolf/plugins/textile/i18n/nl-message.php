<?php

    /**
     * Dutch translation for plugin textile
     *
     * @package Plugins
     * @subpackage textile
     *
     * @author Fortron
     * @version Wolf 0.6.0
     */

    return array(
    'Allows you to compose page parts or snippets using the Textile text filter.' => 'Biedt de mogelijkheid tot het samenstellen van een pagina of snippers met de Textile filter',
	'Textile filter' => 'Textile filter',
    );
