<?php

    /**
     * YourLanguage file for plugin archive
     *
     * @package Plugins
     * @subpackage archive
     *
     * @author Your Name <email@domain.something>
     * @version Wolf x.y.z
     */

    return array(
    	'Archive' => 'アーカイブ',
	'Provides an Archive pagetype behaving similar to a blog or news archive.' => '提供のブログやニュースのアーカイブと同様の動作アーカイブページタイプ。',
    );