<?php

    /**
     * Spanish file for plugin page_not_found
     *
     * @package Plugins
     * @subpackage page_not_found
     *
     * @author andrewmman
     * @version Wolf 0.7
     */

    return array(
    'Page not found' => 'Página no encontrada',
	'Provides Page not found page types.' => 'Proporciona tipos de página para "Página no encontrada".',
    );