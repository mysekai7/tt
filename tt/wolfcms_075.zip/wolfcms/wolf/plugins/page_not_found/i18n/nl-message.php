<?php

    /**
     * Dutch translation for plugin page_not_found
     *
     * @package Plugins
     * @subpackage page_not_found
     *
     * @author Fortron
     * @version Wolf 0.6.0
     */

    return array(
    'Page not found' => 'Pagina niet gevonden',
	'Provides Page not found page types.' => 'Biedt een pagina niet gevonden paginatype.',
    );