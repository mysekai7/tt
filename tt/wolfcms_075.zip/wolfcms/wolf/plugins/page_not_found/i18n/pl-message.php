<?php

    /**
     * Polish file for plugin page_not_found
     *
     * @package Plugins
     * @subpackage page_not_found
     *
     * @author Piotr Fuz <piotr.fuz@gmail.com> and Pawel Balicki <kilab1@o2.pl>
     * @version Wolf 0.6.0
     */

    return array(
    	'Page not found' => 'Typ strony \'Strona nie została odnaleziona\'',
	'Provides Page not found page types.' => 'Dostarcza typ strony \'Strona nie została odnaleziona\'.',
    );
