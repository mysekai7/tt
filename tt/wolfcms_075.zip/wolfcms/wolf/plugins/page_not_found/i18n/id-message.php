<?php

    /**
     * Indonesian file for plugin page_not_found
     *
     * @package Plugins
     * @subpackage page_not_found
     *
     * @author Devi Mandiri <devi.mandiri@gmail.com>
     * @version Wolf 0.7.x
     */

    return array(
    	'Page not found' => 'Halaman tidak ditemukan',
		'Provides Page not found page types.' => 'Menyediakan tipe halaman "Halaman tidak ditemukan".',
    );
