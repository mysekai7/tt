<?php

    /**
     * Romanian file for plugin page_not_found
     *
     * @package Plugins
     * @subpackage page_not_found
     *
     * @author Cosmin Huţanu <urecheatu007@gmail.com>
     * @version Wolf 0.6.0
     */

    return array(
    'Page not found' => 'Pagina nu a fost găsită',
	'Provides Page not found page types.' => 'Face disponibile tipuri de pagină pentru conţinut care nu a fost găsit.',
    );