<?php

   /**
     * Russian language file
     *
     * @package Plugins
     * @subpackage page_not_found
     *
     * @author Dmitry Kostromin <kostromind@gmail.com>
     * @version Wolf 0.6.0
     * @last modified from 07 February 2010
     */
	 
	 
	 
    return array(
    	'Page not found' => 'Страница не найдена',
		'Provides Page not found page types.' => 'Обеспечивает тип страницы — «Страница не найдена»',
    );