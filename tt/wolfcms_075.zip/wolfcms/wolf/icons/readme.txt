
Wolf CMS Icon Set
-----------------

This project aims to replace all the current icons used in the Wolf CMS administration, as well as provide a nice range of icons that plugin developers can use to make their work consistent with the built-in tools. 

Copyright (C) 2010 Joseph North. All rights reserved.
